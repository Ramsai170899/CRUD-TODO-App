from flask import Flask, render_template, request, redirect, url_for
import json
from flask import jsonify
import os

app = Flask(__name__)
DATA_FILE = 'data.json'


def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w') as f:
            json.dump({}, f)
    with open(DATA_FILE, 'r') as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


@app.route('/rename/<old_name>', methods=['POST'])
def rename(old_name):
    new_name = request.form['new_name']
    data = load_data()
    if new_name not in data:
        data[new_name] = data.pop(old_name)
        save_data(data)
    return redirect(url_for('index'))


@app.route('/edit_item/<name>', methods=['POST'])
def edit_item(name):
    data = load_data()
    if isinstance(data[name], list):
        index = int(request.form['index'])
        new_value = request.form['new_value']
        data[name][index] = new_value
    else:
        old_key = request.form['old_key']
        new_key = request.form['new_key']
        new_value = request.form['new_value']
        if old_key in data[name]:
            data[name].pop(old_key)
            data[name][new_key] = new_value
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/move_item/<name>/<int:index>/<direction>')
def move_item(name, index, direction):
    data = load_data()
    items = data[name]
    if isinstance(items, list):
        if direction == 'up' and index > 0:
            items[index], items[index - 1] = items[index - 1], items[index]
        elif direction == 'down' and index < len(items) - 1:
            items[index], items[index + 1] = items[index + 1], items[index]
        save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/move_item/<name>/<key>/<direction>')
def move_dict_item(name, key, direction):
    data = load_data()
    if name not in data or not isinstance(data[name], dict):
        return redirect(url_for('view', name=name))

    items = list(data[name].items())  
    index = next((i for i, (k, _) in enumerate(items) if k == key), None)

    if index is None:
        return redirect(url_for('view', name=name))

    if direction == 'up' and index > 0:
        items[index], items[index - 1] = items[index - 1], items[index]
    elif direction == 'down' and index < len(items) - 1:
        items[index], items[index + 1] = items[index + 1], items[index]

    data[name] = dict(items)
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/')
def index():
    data = load_data()
    return render_template('index.html', data=data)


@app.route('/create', methods=['POST'])
def create():
    name = request.form['name']
    dtype = request.form['type']
    data = load_data()
    if name in data:
        return redirect(url_for('index'))
    data[name] = [] if dtype == 'list' else {}
    save_data(data)
    return redirect(url_for('index'))


@app.route('/view/<name>')
def view(name):
    data = load_data()
    return render_template('view.html', name=name, items=data[name])


@app.route('/add/<name>', methods=['POST'])
def add(name):
    data = load_data()
    if isinstance(data[name], list):
        item = request.form['item']
        data[name].append(item)
    else:
        key = request.form['key']
        value = request.form['value']
        data[name][key] = value
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/delete_item/<name>/<key>')
def delete_item(name, key):
    data = load_data()
    if isinstance(data[name], list):
        data[name].remove(key)
    else:
        data[name].pop(key, None)
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/delete/<name>')
def delete(name):
    data = load_data()
    data.pop(name, None)
    save_data(data)
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
