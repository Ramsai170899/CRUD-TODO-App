from flask import Flask, render_template, request, redirect, url_for
import json
import os

app = Flask(__name__)
DATA_FILE = 'data.json'


def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w') as f:
            json.dump({}, f)
    with open(DATA_FILE, 'r') as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


@app.route('/')
def index():
    data = load_data()
    return render_template('index.html', data=data)


@app.route('/create', methods=['POST'])
def create():
    name = request.form['name']
    dtype = request.form['dtype']
    data = load_data()
    if name not in data:
        data[name] = [] if dtype == 'list' else {}
        save_data(data)
    return redirect(url_for('index'))


@app.route('/view/<name>')
def view(name):
    data = load_data()
    return render_template('view.html', name=name, items=data[name])


@app.route('/add/<name>', methods=['POST'])
def add(name):
    data = load_data()
    if isinstance(data[name], list):
        item = request.form['item']
        data[name].append(item)
    else:
        key = request.form['key']
        value = request.form['value']
        data[name][key] = value
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/delete_item/<name>/<key>')
def delete_item(name, key):
    data = load_data()
    if isinstance(data[name], list):
        data[name].remove(key)
    else:
        data[name].pop(key, None)
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/delete/<name>')
def delete(name):
    data = load_data()
    data.pop(name, None)
    save_data(data)
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
