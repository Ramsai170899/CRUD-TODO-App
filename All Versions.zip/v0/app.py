import json
import os

DATA_FILE = 'data.json'


def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, 'r') as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)


def show_menu():
    print("\n--- List/Dict Manager ---")
    print("1. View all")
    print("2. Create new")
    print("3. View specific")
    print("4. Add item")
    print("5. Edit item")
    print("6. Delete item")
    print("7. Rename list/dict")
    print("8. Delete list/dict")
    print("9. Reorder list")
    print("0. Exit")


def create(data):
    name = input("Enter name: ")
    if name in data:
        print("Name already exists.")
        return
    typ = input("Enter type (list/dict): ").strip().lower()
    if typ == 'list':
        data[name] = []
    elif typ == 'dict':
        data[name] = {}
    else:
        print("Invalid type.")


def view_all(data):
    print("\nAll lists/dictionaries:")
    for name, value in data.items():
        typ = "List" if isinstance(value, list) else "Dictionary"
        print(f"• {name} ({typ})")


def view_specific(data):
    name = input("Enter name: ")
    if name not in data:
        print("Not found.")
        return
    print(f"\n{name}:")
    if isinstance(data[name], list):
        for i, item in enumerate(data[name]):
            print(f"{i + 1}. {item}")
    else:
        for k, v in data[name].items():
            print(f"{k}: {v}")


def add_item(data):
    name = input("Enter name: ")
    if name not in data:
        print("Not found.")
        return
    if isinstance(data[name], list):
        item = input("Enter item to add: ")
        data[name].append(item)
    else:
        key = input("Enter key: ")
        value = input("Enter value: ")
        data[name][key] = value


def edit_item(data):
    name = input("Enter name: ")
    if name not in data:
        print("Not found.")
        return
    if isinstance(data[name], list):
        index = int(input("Enter index (starting from 1): ")) - 1
        if 0 <= index < len(data[name]):
            new_value = input("Enter new value: ")
            data[name][index] = new_value
        else:
            print("Invalid index.")
    else:
        key = input("Enter key to edit: ")
        if key in data[name]:
            new_value = input("Enter new value: ")
            data[name][key] = new_value
        else:
            print("Key not found.")


def delete_item(data):
    name = input("Enter name: ")
    if name not in data:
        print("Not found.")
        return
    if isinstance(data[name], list):
        index = int(input("Enter index (starting from 1): ")) - 1
        if 0 <= index < len(data[name]):
            data[name].pop(index)
        else:
            print("Invalid index.")
    else:
        key = input("Enter key to delete: ")
        if key in data[name]:
            del data[name][key]
        else:
            print("Key not found.")


def rename(data):
    old_name = input("Current name: ")
    if old_name not in data:
        print("Not found.")
        return
    new_name = input("New name: ")
    if new_name in data:
        print("Name already exists.")
        return
    data[new_name] = data.pop(old_name)


def delete(data):
    name = input("Enter name: ")
    if name in data:
        del data[name]
        print("Deleted.")
    else:
        print("Not found.")


def reorder_items(data):
    name = input("Enter list/dict name: ")
    if name not in data:
        print("Not found.")
        return

    if isinstance(data[name], list):
        print("Current list:")
        for i, item in enumerate(data[name]):
            print(f"{i + 1}. {item}")
        new_order = input(
            "Enter new order as comma-separated indices (e.g., 2,1,3): ")
        try:
            indices = list(map(lambda x: int(x) - 1, new_order.split(',')))
            if set(indices) != set(range(len(data[name]))):
                print("Invalid reorder input.")
                return
            data[name] = [data[name][i] for i in indices]
        except:
            print("Invalid input.")
    elif isinstance(data[name], dict):
        print("Current dictionary keys:")
        for k in data[name]:
            print(k)
        new_order = input(
            "Enter new order of keys (comma-separated): ").split(',')
        if set(new_order) != set(data[name].keys()):
            print("Invalid reorder input. Keys must match exactly.")
            return
        new_dict = {key: data[name][key] for key in new_order}
        data[name] = new_dict
    else:
        print("Invalid data type.")


def main():
    data = load_data()
    while True:
        show_menu()
        choice = input("Choose: ").strip()
        if choice == '1':
            view_all(data)
        elif choice == '2':
            create(data)
        elif choice == '3':
            view_specific(data)
        elif choice == '4':
            add_item(data)
        elif choice == '5':
            edit_item(data)
        elif choice == '6':
            delete_item(data)
        elif choice == '7':
            rename(data)
        elif choice == '8':
            delete(data)
        elif choice == '9':
            reorder_items(data)
        elif choice == '0':
            save_data(data)
            print("Goodbye!")
            break
        else:
            print("Invalid option.")
        save_data(data)


if __name__ == '__main__':
    main()
