from flask import Flask, render_template, request, redirect, url_for
import json
from flask import jsonify
import os

app = Flask(__name__)
DATA_FILE = 'data.json'


def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w') as f:
            json.dump({}, f)
    with open(DATA_FILE, 'r') as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


@app.route('/rename/<old_name>', methods=['POST'])
def rename(old_name):
    new_name = request.form['new_name']
    data = load_data()
    if new_name not in data:
        data[new_name] = data.pop(old_name)
        save_data(data)
    return redirect(url_for('index'))


@app.route('/edit_item/<name>', methods=['POST'])
def edit_item(name):
    data = load_data()
    highlight = ""
    if isinstance(data[name], list):
        index = int(request.form['index'])
        new_value = request.form['new_value']
        data[name][index] = new_value
        highlight = new_value
    else:
        old_key = request.form['old_key']
        new_key = request.form['new_key']
        new_value = request.form['new_value']
        if old_key in data[name]:
            data[name].pop(old_key)
            data[name][new_key] = new_value
        highlight = new_key
    save_data(data)
    return redirect(url_for('view', name=name, highlight=highlight))


@app.route('/move_item/<name>/<int:index>/<direction>')
def move_item(name, index, direction):
    data = load_data()
    items = data[name]
    highlight = ""
    if isinstance(items, list):
        if direction == 'up' and index > 0:
            items[index], items[index - 1] = items[index - 1], items[index]
            highlight = items[index - 1]
        elif direction == 'down' and index < len(items) - 1:
            items[index], items[index + 1] = items[index + 1], items[index]
            highlight = items[index + 1]
        save_data(data)
    return redirect(url_for('view', name=name, highlight=highlight))


@app.route('/reorder_list/<name>', methods=['POST'])
def reorder_list(name):
    data = load_data()
    if name in data and isinstance(data[name], list):
        new_order = request.get_json().get('items', [])
        if set(new_order) == set(data[name]):
            data[name] = new_order
            save_data(data)
    return ('', 204)


@app.route('/reorder_dict/<name>', methods=['POST'])
def reorder_dict(name):
    data = load_data()
    if name in data and isinstance(data[name], dict):
        current_items = data[name]
        new_keys = request.get_json().get('keys', [])
        if set(new_keys) == set(current_items.keys()):
            reordered = {key: current_items[key] for key in new_keys}
            data[name] = reordered
            save_data(data)
    return ('', 204)


@app.route('/move_item/<name>/<key>/<direction>')
def move_dict_item(name, key, direction):
    data = load_data()
    if name not in data or not isinstance(data[name], dict):
        return redirect(url_for('view', name=name))

    items = list(data[name].items())
    index = next((i for i, (k, _) in enumerate(items) if k == key), None)

    if index is None:
        return redirect(url_for('view', name=name))

    if direction == 'up' and index > 0:
        items[index], items[index - 1] = items[index - 1], items[index]
    elif direction == 'down' and index < len(items) - 1:
        items[index], items[index + 1] = items[index + 1], items[index]

    data[name] = dict(items)
    save_data(data)
    return redirect(url_for('view', name=name, highlight=key))


@app.route('/')
def index():
    data = load_data()
    return render_template('index.html', data=data)


@app.route('/create', methods=['POST'])
def create():
    name = request.form['name']
    dtype = request.form['type']
    data = load_data()
    if name in data:
        return redirect(url_for('index'))
    data[name] = [] if dtype == 'list' else {}
    save_data(data)
    return redirect(url_for('index'))


@app.route('/view/<name>')
def view(name):
    data = load_data()
    return render_template('view.html', name=name, items=data[name])


@app.route('/add/<name>', methods=['POST'])
def add(name):
    data = load_data()
    if isinstance(data[name], list):
        item = request.form['item']
        data[name].append(item)
    else:
        key = request.form['key']
        value = request.form['value']
        data[name][key] = value
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/delete_item/<name>/<key>')
def delete_item(name, key):
    data = load_data()
    if isinstance(data[name], list):
        data[name].remove(key)
    else:
        data[name].pop(key, None)
    save_data(data)
    return redirect(url_for('view', name=name))


@app.route('/delete/<name>')
def delete(name):
    data = load_data()
    data.pop(name, None)
    save_data(data)
    return redirect(url_for('index'))


@app.route('/reorder/<name>', methods=['POST'])
def reorder(name):
    if request.is_json:
        data = load_data()
        items = request.json.get('items')

        if isinstance(data[name], list):
            data[name] = items
        elif isinstance(data[name], dict):
            original_dict = data[name]
            new_dict = {k: original_dict[k]
                        for k in items if k in original_dict}
            data[name] = new_dict

        save_data(data)
        return jsonify(success=True)
    return jsonify(success=False), 400


if __name__ == '__main__':
    app.run(debug=True)
